package cucumberJava; 

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class annotation { 
   WebDriver driver = null; 
	
   @Given("^I have open the browser$") 
   public void openBrowser() { 
      driver = new FirefoxDriver(); 
   } 
	
   @When("^I open Google & enter text in search text box$") 
   public void goToGoogle() { 
      driver.navigate().to("https://www.google.com/"); 
      driver.findElement(By.id("lst-ib")).sendKeys("send flowers to delhi");
   } 
	
   @Then("^Search result should be displayed$") 
   public void searchResult() { 
       String actualTitle=driver.getTitle();
         String expectedTitle="Google";
         if(expectedTitle.contentEquals(actualTitle)){
        	 driver.findElement(By.name("btnG")).click();
        	 System.out.println("Test Passed!");
         }
         else{
        	 System.out.println("Test Failed!");}
         
         }
         																					
    @And("^I take a screenshot & Screenshot should be saved$")
    public void screenshotResult() { 
    	try {
			Thread.sleep(5000);
		} catch (InterruptedException e1) {
			
			e1.printStackTrace();
		}
    	File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
    	try {
			FileUtils.copyFile(scrFile, new File("screenshotSave\\scrshot.jpeg"));
		} catch (IOException e) {
			
			e.printStackTrace();
		}
   }
      
   @Then("^Terms link should be present$")
   	public void verifyLink(){
	   if(driver.findElements(By.xpath("/html/body/div[1]/div[6]/div[4]/div[9]/div/div/div/div[2]/span/span/a[4]")).size() != 0){
		   System.out.println("Element is Present");
		   }else{
		   System.out.println("Element is Absent");
		   }
	   
	   driver.close(); 
   }
   }

